var nome = "Darwin"
var notaDoPrimeiroBimestre = 9.4355
var notaDoSegundoBimestre = 7.234
var notaDoTerceiroBimestre = 4.234
var notaDoQuartoBimestre = 2.183

var somaNotaFinal = notaDoPrimeiroBimestre + notaDoSegundoBimestre + notaDoTerceiroBimestre + notaDoQuartoBimestre

var notaFinal = somaNotaFinal / 4 


var notaFixada = notaFinal.toFixed(2)


console.log("Ben vindo " + nome)
console.log(notaFinal)
console.log(notaFixada)


//Revisáo
//Variáveis, string, console.log, toFixed, operações, matemáticas, contatenação